package com.dicoding.exam.exam1

// TODO 1
// Fungsi untuk mengecek apakah suatu angka adalah genap
fun isEvenNumber(number: Int): Boolean {
    return number % 2 == 0
}

// TODO 2
// Fungsi untuk mengecek apakah suatu angka lebih dari 5
fun moreThanFive(number: Int): Boolean {
    return number > 5
}

// TODO 3
// Fungsi untuk menghitung result = number * (number + 10)
fun result(number: Int): Int {
    return number * (number + 10)
}