package com.dicoding.exam.optionalexam2

// TODO
fun minAndMax(number: Int): Int {
    // Ubah number menjadi string untuk mengakses digit-digital individual
    val digits = number.toString().map { it.toString().toInt() }

    // Cari digit terkecil dan terbesar
    val minDigit = digits.minOrNull() ?: 0
    val maxDigit = digits.maxOrNull() ?: 0

    // Mengembalikan hasil penjumlahan digit terkecil dan terbesar
    return minDigit + maxDigit
}
