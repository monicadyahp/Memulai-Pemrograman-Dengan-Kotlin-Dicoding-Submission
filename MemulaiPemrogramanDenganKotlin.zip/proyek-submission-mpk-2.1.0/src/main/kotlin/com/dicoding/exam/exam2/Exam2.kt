package com.dicoding.exam.exam2

// TODO 1
// Fungsi untuk menghitung valueA + (valueB - valueC), di mana valueC memiliki nilai default 50 jika null
fun calculate(valueA: Int, valueB: Int, valueC: Int?): Int {
    val c = valueC ?: 50  // Jika valueC bernilai null, ganti dengan 50
    return valueA + (valueB - c)
}

// TODO 2
// Fungsi untuk mengembalikan teks "Result is $result"
fun result(result: Int): String {
    return "Result is $result"
}