package com.dicoding.exam.optionalexam3

// TODO
fun manipulateString(str: String, int: Int): String {
    // Regex untuk menemukan angka dalam string
    val regex = Regex("\\d+")
    val matchResult = regex.find(str)

    return if (matchResult != null) {
        // Jika ada angka dalam string
        val number = matchResult.value.toInt() // Ambil angka dan konversi ke Int
        val multipliedValue = number * int // Kalikan angka dengan input int
        // Gabungkan string yang tidak mengandung angka dengan hasil kali
        str.replace(matchResult.value, "") + multipliedValue
    } else {
        // Jika tidak ada angka dalam string
        str + int // Gabungkan langsung string dengan angka
    }
}
