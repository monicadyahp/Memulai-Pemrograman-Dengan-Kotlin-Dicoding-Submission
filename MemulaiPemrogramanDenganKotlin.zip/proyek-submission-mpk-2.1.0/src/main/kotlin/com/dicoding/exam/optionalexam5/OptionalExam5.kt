package com.dicoding.exam.optionalexam5

// TODO
val concatString: (String, String) -> String = { s1, s2 -> s1 + s2 }
